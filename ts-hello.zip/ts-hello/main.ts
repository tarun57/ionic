
import {Likecomponent} from './like.component';
let component = new Likecomponent(10,true);
component.onclick();
//console.log(component.likescount= 10, component.isSelected= true);
console.log(component.likescount, component.isSelected);