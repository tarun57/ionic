"use strict";
exports.__esModule = true;
var like_component_1 = require("./like.component");
var component = new like_component_1.Likecomponent(10, true);
component.onclick();
//console.log(component.likescount= 10, component.isSelected= true);
console.log(component.likescount, component.isSelected);
