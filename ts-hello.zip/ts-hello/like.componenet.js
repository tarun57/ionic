"use strict";
exports.__esModule = true;
var Likecomponent = /** @class */ (function () {
    function Likecomponent() {
    }
    return Likecomponent;
}());
exports.Likecomponent = Likecomponent;
onClick();
{
    this.likescount += (this.isSelected) ? 1 : -1;
    this.isSelected = !this.isSelected;
}
